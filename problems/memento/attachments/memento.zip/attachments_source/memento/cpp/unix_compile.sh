#!/bin/bash

g++ -O2 -std=c++11 -g runner.cpp memento.cpp -o memento
