#include <iostream>
#include <vector>

using namespace std;

std::vector<std::pair<int,int>> run(std::vector<std::pair<int,int>> edges);
