#!/bin/bash

./memento < seed.in
